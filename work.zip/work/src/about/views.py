from django.shortcuts import render
from .models import Owner

def index(request):
    queryset = Owner.objects.all()
    context = {
          'object_list': queryset,
     }
    print (context)
    return render(request, 'index.html', context )

